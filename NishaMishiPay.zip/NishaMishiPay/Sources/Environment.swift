//
//  Environment.swift
//  QuickScanner
//
//  Created by Nisha Yadav on 25/08/20.
//  Copyright © 2018 Lukasz Szarkowicz. All rights reserved.
//

import Foundation

enum Environment {

    case simulator
    case device

    static var current: Environment {

        #if targetEnvironment(simulator)
            return .simulator
        #else
            return .device
        #endif
    }
}
