//
//  QuickScanner.h
//  QuickScanner
//
//  Created by Nisha Yadav on 25/08/20.
//  Copyright © 2018 Lukasz Szarkowicz. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for QuickScanner.
FOUNDATION_EXPORT double QuickScannerVersionNumber;

//! Project version string for QuickScanner.
FOUNDATION_EXPORT const unsigned char QuickScannerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QuickScanner/PublicHeader.h>


