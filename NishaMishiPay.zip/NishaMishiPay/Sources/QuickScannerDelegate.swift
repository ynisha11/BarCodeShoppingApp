//
//  QuickScannerDelegate.swift
//  QuickScanner
//
//  Created by Nisha Yadav on 25/08/20.
//  Copyright © 2018 Lukasz Szarkowicz. All rights reserved.
//

import UIKit


public protocol QuickScannerDelegate: class {

    var videoPreview: UIView { get }
    /// rect of focus while scanning. Metadata outside of this rect will be skipped
    var rectOfInterest: UIView { get }

    func quickScanner(_ scanner: QuickScanner, didCaptureCode code: String, type: CodeType)
    func quickScanner(_ scanner: QuickScanner, didReceiveError error: QuickScannerError)
    func quickScannerDidSetup(_ scanner: QuickScanner)
    func quickScannerDidEndScanning(_ scanner: QuickScanner)
}
