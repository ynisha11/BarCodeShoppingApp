//
//  QuickScanner+Types.swift
//  QuickScanner
//
//  Created by Nisha Yadav on 25/08/20.
//  Copyright © 2018 Lukasz Szarkowicz. All rights reserved.
//

import Foundation
import AVFoundation

public typealias CameraPosition = AVCaptureDevice.Position
public typealias CodeType = AVMetadataObject.ObjectType

