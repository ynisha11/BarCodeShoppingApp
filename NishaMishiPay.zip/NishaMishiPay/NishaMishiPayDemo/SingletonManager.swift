//
//  SingletonManager.swift
//  Shopping App
//
//  Created by Shyam Pindoria on 8/11/17.
//  Copyright © 2017 Shyam Pindoria. All rights reserved.
//

import Foundation

class SingletonManager {
    static let model = Model()
}
